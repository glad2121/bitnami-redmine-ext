$(function($) {
    $('ul.stories').liveFilter('basic');
});
